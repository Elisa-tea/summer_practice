#pragma once


#include <iostream>
#include <iomanip>
#include <ctime>

using namespace std;


// � ���� 8 ������������� �����
static int cx[8] = { 1,   1,   2,   2,  -1,  -1,  -2,  -2 };
static int cy[8] = { 2,  -2,   1,  -1,   2,  -2,   1,  -1 };


bool limits(int x, int y, int N);
bool isempty(int a[], int x, int y, int N);
int getDegree(int a[], int x, int y, int N);
bool nextMove(int a[], int* x, int* y, int N);
void print(int a[], int N);
bool findClosedTour(int N, int iniX, int iniY);