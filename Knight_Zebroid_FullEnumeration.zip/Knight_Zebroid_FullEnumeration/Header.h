#pragma once


#include <iostream>
#include <iomanip>
#include <ctime>

using namespace std;



int isSafe(int N, int x, int y, int sol[8][8]);
void printSolution(int N, int sol[8][8]);
int solveKT(int N, int iniX, int iniY);
int solveKTUtil(int N, int x, int y, int movei, int sol[8][8], int xMove[8], int yMove[8], int iniX, int iniY);
